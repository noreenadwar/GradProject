#ifndef __sensorApp_H
#define __sensorApp_H
#include <fstream>
#include <string.h>
#include "inet/applications/base/ApplicationBase.h"
#include "inet/transportlayer/contract/udp/UdpSocket.h"
#include "inet/common/ModuleAccess.h"
#include "inet/common/packet/Packet.h"
#include "inet/networklayer/common/L3AddressResolver.h"
#include "inet/transportlayer/contract/udp/UdpControlInfo_m.h"

#include "inet/common/ModuleAccess.h"
#include "inet/common/TagBase_m.h"
#include "inet/common/TimeTag_m.h"
#include "inet/common/lifecycle/ModuleOperations.h"
#include "inet/common/packet/Packet.h"
#include "inet/networklayer/common/FragmentationTag_m.h"
#include "inet/networklayer/common/L3AddressResolver.h"
#include "inet/transportlayer/contract/udp/UdpControlInfo_m.h"
#include "inet/applications/base/ApplicationBase.h"
#include "inet/common/clock/ClockUserModuleMixin.h"
#include "inet/transportlayer/contract/udp/UdpSocket.h"
#include "../MyPacket_m.h"


#include "inet/Encryption/base58/define.h"
#include "inet/Encryption/RSA/rsa.h"
#include "inet/Encryption/base58/base58.h"
#include "inet/Encryption/tea/xtea.h"
#include "inet/Encryption/AES/aes.h"
#include "inet/Encryption/SHA512/sha512.h"

#define NANO 0.001
#define PICO 0.000001
namespace inet {

struct packet_info{
    int id;
    double time;
    Packet *packet;
    std::string to;
    int type;
    bool Ask;
};
struct Node{
    std::string name;
    int topic;
    double Energy;
    double X;
    double Y;
    double header;
};


class INET_API sensorApp : public ApplicationBase, public UdpSocket::ICallback
{
  protected:
    enum SelfMsgKinds { START = 1,SEND};
    enum Status { DEAD = 1, ALIVE };
    int ID;
    std::string Scenario;
    UdpSocket socket;
    int localPort = -1;
    L3Address multicastGroup;
    cMessage *selfMsg = nullptr;
    int Device_Type;
    int topic;
    double Energy;
    double X;
    double Y;
    define d;
    int myStatus;
    std::vector<packet_info> packet_infos;
    std::vector<Node> Nodes;
    std::vector<std::string> colors;
    std::vector<Packet*> PacketGrop;
    // statistics
    int numSent = 0;
    int numReceived = 0;
    int PublishID=0;
    double HeadId;
    std::vector<std::string> debug;
  public:
    sensorApp() {}
    virtual ~sensorApp(){
        cancelAndDelete(selfMsg);
    };

  protected:
    virtual void setSocketOptions(){
        bool receiveBroadcast = par("receiveBroadcast");
        if (receiveBroadcast)
            socket.setBroadcast(true);

        MulticastGroupList mgl = getModuleFromPar<IInterfaceTable>(par("interfaceTableModule"), this)->collectMulticastGroups();
        socket.joinLocalMulticastGroups(mgl);

        // join multicastGroup
        const char *groupAddr = par("multicastGroup");
        multicastGroup = L3AddressResolver().resolve(groupAddr);
        if (!multicastGroup.isUnspecified()) {
            if (!multicastGroup.isMulticast())
                throw cRuntimeError("Wrong multicastGroup setting: not a multicast address: %s", groupAddr);
            socket.joinMulticastGroup(multicastGroup);
        }
        socket.setCallback(this);
    };

  protected:
    virtual int numInitStages() const override { return NUM_INIT_STAGES; }
    virtual void initialize(int stage) override{
        ApplicationBase::initialize(stage);
        if (stage == INITSTAGE_LOCAL) {
            for(int i = 0; i< getParentModule()->getIndex(); i++)
                rand();
            d.set(par("Scenarios"));
            d.sett(1);
            Device_Type = _sensor;
            topic = _temperature;
            Energy = 500000;
            ID = getParentModule()->getIndex();
            numReceived = 0;
            numSent = 0;
            HeadId=d._Nodes[ID].header;
            Scenario = getParentModule()->getParentModule()->par("Scenario").stringValue();

            getParentModule()->getDisplayString().setTagArg("p", 0, d._Nodes[ID].X);
            getParentModule()->getDisplayString().setTagArg("p", 1, d._Nodes[ID].Y);
            WATCH(numReceived);
            localPort = par("localPort");
            selfMsg = new cMessage("sensorAppTimer");
        }
    };
    int get_num(int from , int to){
        int a = (rand()%(to -from ));
        if(a<0)
            a *=-1;
      return a;
    }
    void handle_START(cMessage *msg);
    virtual void handleMessageWhenUp(cMessage *msg) override{
        if (msg->isSelfMessage()) {
            ASSERT(msg == selfMsg);
            switch (selfMsg->getKind()) {
                case START:
                    handle_START(msg);

                    break;
                case SEND:
                    if(getParentModule()->getIndex()!=HeadId){
                        std::ostringstream str;
                        str << getParentModule()->getName()<<"["<< HeadId << "]" ;
                        Send_PUBLISH(Create_PUBLISH(),str.str().c_str() ,5000);
                    }else{
                        Send_PUBLISH(Create_PUBLISH(),"controller" ,5000);
                        PublishID++;
                    }
                    selfMsg->setKind(SEND);
                    scheduleAt(simTime()+10, selfMsg);
                break;

                default:
                    throw cRuntimeError("Invalid kind %d in self message", (int)selfMsg->getKind());
            }
        }
        else if (msg->arrivedOn("socketIn"))
            socket.processMessage(msg);
        else
            throw cRuntimeError("Unknown incoming gate: '%s'", msg->getArrivalGate()->getFullName());
    };

    virtual void finish() override{
        ApplicationBase::finish();
        debug_file();
        recordScalar("packets sent", numSent);
        recordScalar("packets received", numReceived);
    };
    virtual void refreshDisplay() const override{
        ApplicationBase::refreshDisplay();

        char buf[100];
        sprintf(buf, "rcvd: %d pks\nsent: %d pks", numReceived, numSent);
        getDisplayString().setTagArg("t", 0, buf);
    };

    virtual void socketDataArrived(UdpSocket *socket, Packet *packet) override{
        const auto& msg = packet->peekAtFront<base_msg>();
        switch (msg->getPacket_type()) {
            case _CONNECT :
                handle_CONNECT(packet);
            break;
            case _Info :
                handle_Info(packet);
            break;
            case _Join :
                handle_Join(packet);
            break;
            case _Order :
                handle_Order(packet);
            break;
            case _PUBLISH :
                handle_PUBLISH(packet);
            break;
            case _ACK :
                handle_ACK(packet);
            break;
        }
        emit(packetReceivedSignal, packet);
        delete packet;
        numReceived++;
    };
    virtual void socketErrorArrived(UdpSocket *socket, Indication *indication) override{
        EV_WARN << "Ignoring UDP error report " << indication->getName() << endl;
        delete indication;
    };
    virtual void socketClosed(UdpSocket *socket) override{
        if (operationalState == State::STOPPING_OPERATION)
            startActiveOperationExtraTimeOrFinish(par("stopOperationExtraTime"));
    };

    virtual void handleStartOperation(LifecycleOperation *operation) override{
        socket.setOutputGate(gate("socketOut"));
        socket.bind(localPort);
        setSocketOptions();

        selfMsg->setKind(START);
        scheduleAt(simTime()+ getParentModule()->getIndex(), selfMsg);
    };
    virtual void handleStopOperation(LifecycleOperation *operation) override{
        cancelEvent(selfMsg);
        if (!multicastGroup.isUnspecified())
            socket.leaveMulticastGroup(multicastGroup);
        socket.close();
        delayActiveOperationFinish(par("stopOperationTimeout"));
    };
    virtual void handleCrashOperation(LifecycleOperation *operation) override{
        cancelEvent(selfMsg);
        if (operation->getRootModule() != getContainingNode(this)) {
            if (!multicastGroup.isUnspecified())
                socket.leaveMulticastGroup(multicastGroup);
            socket.destroy();
        }
    };
    Packet *Create_CONNECT();
    Packet *Create_Info();
    Packet *Create_Join();
    Packet *Create_Order(std::string Device,int Operation,std::string value);
    Packet *Create_PUBLISH();
    Packet *Create_encrypt_PUBLISH();
    Packet *Create_ACK(int ACK_type,int Ack_Flag);

    void Send_CONNECT(Packet *packet,std::string to ,int port);
    void Send_Info(Packet *packet,std::string to ,int port);
    void Send_Join(Packet *packet,std::string to ,int port);
    void Send_Order(Packet *packet,std::string to ,int port);
    void Send_PUBLISH (Packet *packet,std::string to ,int port);

    void Send_ACK(Packet *packet,std::string to ,int port);

    void handle_CONNECT(Packet *packet);
    void handle_Info(Packet *packet);
    void handle_Join(Packet *packet);
    void handle_Order(Packet *packet);
    void handle_PUBLISH(Packet *packet);
    void handle_ACK(Packet *packet);

    int generate_data(){
         srand(time(0));
         int pos = -1 ;
        switch (topic) {
            case _temperature:
                pos = (rand()%(1 - 35)) +30;
                break;
            case _Pressure:
                pos = ((rand() % (0 - 200)));
                break;
            case _Smoke:
                pos = ((rand() % (1 - 100)));
                if(pos < 30)
                    pos = 0;
                else if(pos > 30 &&  pos < 30)
                    pos = 1;
                else
                    pos = 2;
                break;
            case _Gas:
                pos = ((rand() % (1 - 100)));
                if(pos <50){pos = 0;}else{pos = 1;}
                break;
            case _Humidity:
                pos =((rand() % (70 - 80)));
                break;
            default:
                pos =-1;
                break;
        }

         return pos;
     }
    void debug_file(){
        std::ofstream myfile;
        char buf[100];
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        sprintf(buf, "debug/%s.txt",str.str().c_str());
        myfile.open (buf);
        for (auto i = debug.begin(); i != debug.end(); ++i)
            myfile << *i << "\n";
        myfile.close();
    }
    void add_debug(std::string title, double value){
        std::ostringstream str1;
        str1 << title << " : "  << value << " on " << simTime() ;
        debug.push_back(str1.str().c_str()) ;
    }
    void add_debug(std::string title){
        debug.push_back(title) ;
    }
    void energyReceive(int bits){
         if (this->myStatus == ALIVE)
             Energy = Energy - (double) bits *50.0 * NANO;
         if((Energy<=0)&&(this->myStatus==ALIVE)){
             this->myStatus=DEAD;
             getParentModule()->getDisplayString().setTagArg("o", 0, "black");
         }
     }

     void energyTransmit(int bits, int dist){
         if (this->myStatus == ALIVE)
             Energy = Energy - bits * 10 * PICO * dist + (double) bits *50.0 * NANO;
         if((Energy<=0)&&(this->myStatus==ALIVE)){
             this->myStatus=DEAD;
             getParentModule()->getDisplayString().setTagArg("o", 0, "black");
         }
     }
     void energyDataAggr(int signals){
         if (this->myStatus == ALIVE)
             Energy = Energy - 5 * NANO * signals;
     }

};


}

#endif

