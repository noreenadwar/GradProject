#include "sensorApp.h"

namespace inet {

Define_Module(sensorApp);

void sensorApp::handle_START(cMessage *msg){
    Send_CONNECT(Create_CONNECT(),"controller" ,5000);
}

Packet *sensorApp::Create_CONNECT(){
    Packet *packet = new Packet("CONNECT");
    const auto& payload = makeShared<_CONNECT_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
    packet->insertAtBack(payload);
  return packet;
}
Packet *sensorApp::Create_Info(){
    Packet *packet = new Packet("Info");
    const auto& payload = makeShared<_Info_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
        payload->setTopic(topic);
        payload->setEnergy(Energy);
        payload->setX(X);
        payload->setY(Y);
    packet->insertAtBack(payload);
  return packet;
};
Packet *sensorApp::Create_Join(){
    Packet *packet = new Packet("Join");
    const auto& payload = makeShared<_Join_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
    packet->insertAtBack(payload);
  return packet;
};
Packet *sensorApp::Create_Order(std::string Device,int Operation,std::string value){
    Packet *packet = new Packet("Order");
    const auto& payload = makeShared<_Order_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
    payload->setDevice(Device.c_str());
    payload->setOperation(Operation);
    payload->setValue(value.c_str());

    packet->insertAtBack(payload);
  return packet;
};
Packet *sensorApp::Create_PUBLISH(){
    Packet *packet = new Packet("PUBLISH");
    const auto& payload = makeShared<_PUBLISH_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());

        payload->setTopic(topic);
        payload->setPUBLISH_ID(PublishID);
        payload->setInt_value(generate_data());

    packet->insertAtBack(payload);
  return packet;
};

Packet *sensorApp::Create_encrypt_PUBLISH(){
    Packet *packet = new Packet("PUBLISH");
    const auto& payload = makeShared<_PUBLISH_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
        int value = generate_data();
        payload->setTopic(topic);
        payload->setPUBLISH_ID(PublishID);
        payload->setInt_value(value);
        crypto::rsa::RSAKeyPair keyPair = crypto::rsa::RSA::generateKeyPair(1024);
       add_debug(" privateKey : " + keyPair.privateKey);
       add_debug(" publicKey  : " + keyPair.publicKey);
       ubyte* buf = new ubyte[20 * 2 + 256];  //256 is key size.
       ubyte* buf2 = new ubyte[20 * 2];

       std::ostringstream str1;
       str1 << value ;

       add_debug(" data : " + str1.str());
       uint64 Enlen = crypto::rsa::RSA::encrypt(keyPair.privateKey, str1.str().c_str(), buf);
       string ret1((char*)buf, Enlen);
       add_debug(" RSA Encryption : " + ret1);

       payload->setData(Enlen);
       payload->setPKey(keyPair.publicKey.c_str());
    packet->insertAtBack(payload);
  return packet;
};

Packet *sensorApp::Create_ACK(int ACK_type,int Ack_Flag){
    Packet *packet = new Packet("ACK");
    const auto& payload = makeShared<_ACK_msg>();
    payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        std::ostringstream str;
        str << getParentModule()->getName()<<"["<< getParentModule()->getIndex() << "]" ;
        payload->setSensor_name(str.str().c_str());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
        payload->setACK_type(ACK_type);
        payload->setAck_Flags(Ack_Flag);

    packet->insertAtBack(payload);
  return packet;
};

void sensorApp::Send_CONNECT(Packet *packet,std::string to ,int port){
    add_debug("Send_CONNECT to controller");
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    packet_info p;
      p.id=numSent;
      p.time = simTime().dbl();
      p.packet = packet;
      p.to  = to;
      p.type =_CONNECT;
      p.Ask = false;
    packet_infos.push_back(p);
    numSent++;
};
void sensorApp::Send_Info(Packet *packet,std::string to ,int port){
    add_debug("Send_Info to controller");
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    packet_info p;
      p.id=numSent;
      p.time = simTime().dbl();
      p.packet = packet;
      p.to  = to;
      p.type =_Info;
      p.Ask = false;
    packet_infos.push_back(p);
    numSent++;
};
void sensorApp::Send_Join(Packet *packet,std::string to ,int port){
    add_debug("Send_Join to Header");
    EV << "Send_Join=============Node: "<< getParentModule()->getIndex()<< "==================="  << "\n";
    EV << to.c_str() << "\n";
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    packet_info p;
      p.id=numSent;
      p.time = simTime().dbl();
      p.packet = packet;
      p.to  = to;
      p.type=_Join;
      p.Ask = false;
    packet_infos.push_back(p);
    numSent++;
};
void sensorApp::Send_Order(Packet *packet,std::string to ,int port){
    add_debug("Send_Order from Header to sensor");
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    packet_info p;
      p.id=numSent;
      p.time = simTime().dbl();
      p.packet = packet;
      p.to  = to;
      p.type=_Order;
      p.Ask = false;
    packet_infos.push_back(p);
    numSent++;
};
void sensorApp::Send_PUBLISH (Packet *packet,std::string to ,int port){
    add_debug("Send_PUBLISH ");
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    packet_info p;
      p.id=numSent;
      p.time = simTime().dbl();
      p.packet = packet;
      p.to  = to;
      p.type=_PUBLISH;
      p.Ask = false;
    packet_infos.push_back(p);
    numSent++;
};
void sensorApp::Send_ACK(Packet *packet,std::string to ,int port){
    add_debug("Send_ACK ");
    EV << "Send_ACK=============Node: "<< getParentModule()->getIndex()<< "==================="  << "\n";
    EV << to.c_str() << "\n";
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    emit(packetSentSignal, packet);
    socket.sendTo(packet, destAddr, port);
    numSent++;

};

void sensorApp::handle_CONNECT(Packet *packet){
    const auto& msg = packet->peekAtFront<_CONNECT_msg>();
    EV << "handle_CONNECT=============Node: "<< getParentModule()->getIndex()<< "==================="  << "\n";
    add_debug("handle_CONNECT ");
}
void sensorApp::handle_Info(Packet *packet){
    const auto& msg = packet->peekAtFront<_Info_msg>();
    add_debug("handle_Info ");
    EV << "=============Node: "<< getParentModule()->getIndex()<< "==================="  << "\n";
    EV << "name:" << msg->getSensor_name()            << "\n";
    EV << "Packet_ID:" << msg->getPacket_ID()     << "\n";
    EV << "Device_Type:" << msg->getDevice_Type()   << "\n";
    EV << "Creation_Time:" << msg->getCreation_Time() << "\n";
    EV << "Arrival_time:" << simTime().dbl() << "\n";
    EV << "Delay:" << simTime().dbl()-msg->getCreation_Time() << "\n";

    EV << "============================================================================" << "\n";
    EV << "topic:" << msg->getTopic() << "\n";
    EV << "Energy:" << msg->getEnergy() << "\n";
    EV << "X:" << msg->getX() << "\n";
    EV << "Y:" << msg->getY() << "\n";
}
void sensorApp::handle_Join(Packet *packet){
    const auto& msg = packet->peekAtFront<_Join_msg>();
    add_debug("handle_Join ");

    Send_ACK(Create_ACK(_Join,_received),msg->getSensor_name(),5000);
}
void sensorApp::handle_Order(Packet *packet){
   const auto& msg = packet->peekAtFront<_Order_msg>();
   add_debug("handle_Order ");
   d.set(par("Scenarios"));
   getParentModule()->getDisplayString().setTagArg("i", 0, d._Nodes[ID].icon.c_str());
   getParentModule()->getDisplayString().setTagArg("i", 1, d._Nodes[ID].color.c_str());
   Send_PUBLISH(Create_PUBLISH(),"controller" ,5000);
   PublishID++;
   selfMsg->setKind(SEND);
   scheduleAt(simTime()+10, selfMsg);

}
void sensorApp::handle_PUBLISH(Packet *packet){
    add_debug("handle_PUBLISH ");
    const auto& msg = packet->peekAtFront<_PUBLISH_msg>();

}
void sensorApp::handle_ACK(Packet *packet){
    add_debug("handle_ACK ");
    const auto& msg = packet->peekAtFront<_ACK_msg>();
   switch (msg->getACK_type()) {
        case _CONNECT:
             Send_Info(Create_Info(), msg->getSensor_name() ,5000);
            break;
        default:
            break;
    }

}

}

