//
// Generated file, do not edit! Created by opp_msgtool 6.0 from inet/clustering/sensorApp/../MyPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include <type_traits>
#include "MyPacket_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp

namespace inet {

Register_Enum(inet::_Packet_type, (inet::_Packet_type::_CONNECT, inet::_Packet_type::_Info, inet::_Packet_type::_Join, inet::_Packet_type::_Order, inet::_Packet_type::_PUBLISH, inet::_Packet_type::_ACK));

Register_Enum(inet::_ACK_type, (inet::_ACK_type::_received, inet::_ACK_type::_reSend, inet::_ACK_type::_Reject));

Register_Enum(inet::_Device_Type, (inet::_Device_Type::_sensor, inet::_Device_Type::_Controller, inet::_Device_Type::_Cloud));

Register_Enum(inet::_sensor_Type, (inet::_sensor_Type::_temperature, inet::_sensor_Type::_Smoke, inet::_sensor_Type::_Pressure, inet::_sensor_Type::_Gas, inet::_sensor_Type::_Humidity));

Register_Class(base_msg)

base_msg::base_msg() : ::inet::FieldsChunk()
{
}

base_msg::base_msg(const base_msg& other) : ::inet::FieldsChunk(other)
{
    copy(other);
}

base_msg::~base_msg()
{
}

base_msg& base_msg::operator=(const base_msg& other)
{
    if (this == &other) return *this;
    ::inet::FieldsChunk::operator=(other);
    copy(other);
    return *this;
}

void base_msg::copy(const base_msg& other)
{
    this->Packet_type = other.Packet_type;
    this->sensor_name = other.sensor_name;
    this->Packet_ID = other.Packet_ID;
    this->Device_Type = other.Device_Type;
    this->Creation_Time = other.Creation_Time;
}

void base_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::FieldsChunk::parsimPack(b);
    doParsimPacking(b,this->Packet_type);
    doParsimPacking(b,this->sensor_name);
    doParsimPacking(b,this->Packet_ID);
    doParsimPacking(b,this->Device_Type);
    doParsimPacking(b,this->Creation_Time);
}

void base_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::FieldsChunk::parsimUnpack(b);
    doParsimUnpacking(b,this->Packet_type);
    doParsimUnpacking(b,this->sensor_name);
    doParsimUnpacking(b,this->Packet_ID);
    doParsimUnpacking(b,this->Device_Type);
    doParsimUnpacking(b,this->Creation_Time);
}

int base_msg::getPacket_type() const
{
    return this->Packet_type;
}

void base_msg::setPacket_type(int Packet_type)
{
    handleChange();
    this->Packet_type = Packet_type;
}

const char * base_msg::getSensor_name() const
{
    return this->sensor_name.c_str();
}

void base_msg::setSensor_name(const char * sensor_name)
{
    handleChange();
    this->sensor_name = sensor_name;
}

int base_msg::getPacket_ID() const
{
    return this->Packet_ID;
}

void base_msg::setPacket_ID(int Packet_ID)
{
    handleChange();
    this->Packet_ID = Packet_ID;
}

int base_msg::getDevice_Type() const
{
    return this->Device_Type;
}

void base_msg::setDevice_Type(int Device_Type)
{
    handleChange();
    this->Device_Type = Device_Type;
}

double base_msg::getCreation_Time() const
{
    return this->Creation_Time;
}

void base_msg::setCreation_Time(double Creation_Time)
{
    handleChange();
    this->Creation_Time = Creation_Time;
}

class base_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_Packet_type,
        FIELD_sensor_name,
        FIELD_Packet_ID,
        FIELD_Device_Type,
        FIELD_Creation_Time,
    };
  public:
    base_msgDescriptor();
    virtual ~base_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(base_msgDescriptor)

base_msgDescriptor::base_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::base_msg)), "inet::FieldsChunk")
{
    propertyNames = nullptr;
}

base_msgDescriptor::~base_msgDescriptor()
{
    delete[] propertyNames;
}

bool base_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<base_msg *>(obj)!=nullptr;
}

const char **base_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *base_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int base_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 5+base->getFieldCount() : 5;
}

unsigned int base_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_Packet_type
        FD_ISEDITABLE,    // FIELD_sensor_name
        FD_ISEDITABLE,    // FIELD_Packet_ID
        FD_ISEDITABLE,    // FIELD_Device_Type
        FD_ISEDITABLE,    // FIELD_Creation_Time
    };
    return (field >= 0 && field < 5) ? fieldTypeFlags[field] : 0;
}

const char *base_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Packet_type",
        "sensor_name",
        "Packet_ID",
        "Device_Type",
        "Creation_Time",
    };
    return (field >= 0 && field < 5) ? fieldNames[field] : nullptr;
}

int base_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "Packet_type") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "sensor_name") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "Packet_ID") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "Device_Type") == 0) return baseIndex + 3;
    if (strcmp(fieldName, "Creation_Time") == 0) return baseIndex + 4;
    return base ? base->findField(fieldName) : -1;
}

const char *base_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_Packet_type
        "string",    // FIELD_sensor_name
        "int",    // FIELD_Packet_ID
        "int",    // FIELD_Device_Type
        "double",    // FIELD_Creation_Time
    };
    return (field >= 0 && field < 5) ? fieldTypeStrings[field] : nullptr;
}

const char **base_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *base_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int base_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void base_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'base_msg'", field);
    }
}

const char *base_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string base_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Packet_type: return long2string(pp->getPacket_type());
        case FIELD_sensor_name: return oppstring2string(pp->getSensor_name());
        case FIELD_Packet_ID: return long2string(pp->getPacket_ID());
        case FIELD_Device_Type: return long2string(pp->getDevice_Type());
        case FIELD_Creation_Time: return double2string(pp->getCreation_Time());
        default: return "";
    }
}

void base_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Packet_type: pp->setPacket_type(string2long(value)); break;
        case FIELD_sensor_name: pp->setSensor_name((value)); break;
        case FIELD_Packet_ID: pp->setPacket_ID(string2long(value)); break;
        case FIELD_Device_Type: pp->setDevice_Type(string2long(value)); break;
        case FIELD_Creation_Time: pp->setCreation_Time(string2double(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'base_msg'", field);
    }
}

omnetpp::cValue base_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Packet_type: return pp->getPacket_type();
        case FIELD_sensor_name: return pp->getSensor_name();
        case FIELD_Packet_ID: return pp->getPacket_ID();
        case FIELD_Device_Type: return pp->getDevice_Type();
        case FIELD_Creation_Time: return pp->getCreation_Time();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'base_msg' as cValue -- field index out of range?", field);
    }
}

void base_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Packet_type: pp->setPacket_type(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_sensor_name: pp->setSensor_name(value.stringValue()); break;
        case FIELD_Packet_ID: pp->setPacket_ID(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_Device_Type: pp->setDevice_Type(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_Creation_Time: pp->setCreation_Time(value.doubleValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'base_msg'", field);
    }
}

const char *base_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr base_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void base_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    base_msg *pp = omnetpp::fromAnyPtr<base_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'base_msg'", field);
    }
}

Register_Class(_CONNECT_msg)

_CONNECT_msg::_CONNECT_msg() : ::inet::base_msg()
{
    this->setPacket_type(_CONNECT);
}

_CONNECT_msg::_CONNECT_msg(const _CONNECT_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_CONNECT_msg::~_CONNECT_msg()
{
}

_CONNECT_msg& _CONNECT_msg::operator=(const _CONNECT_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _CONNECT_msg::copy(const _CONNECT_msg& other)
{
}

void _CONNECT_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
}

void _CONNECT_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
}

class _CONNECT_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
    };
  public:
    _CONNECT_msgDescriptor();
    virtual ~_CONNECT_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_CONNECT_msgDescriptor)

_CONNECT_msgDescriptor::_CONNECT_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_CONNECT_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_CONNECT_msgDescriptor::~_CONNECT_msgDescriptor()
{
    delete[] propertyNames;
}

bool _CONNECT_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_CONNECT_msg *>(obj)!=nullptr;
}

const char **_CONNECT_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_CONNECT_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _CONNECT_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 0+base->getFieldCount() : 0;
}

unsigned int _CONNECT_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    return 0;
}

const char *_CONNECT_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

int _CONNECT_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->findField(fieldName) : -1;
}

const char *_CONNECT_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

const char **_CONNECT_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_CONNECT_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _CONNECT_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _CONNECT_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_CONNECT_msg'", field);
    }
}

const char *_CONNECT_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _CONNECT_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: return "";
    }
}

void _CONNECT_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_CONNECT_msg'", field);
    }
}

omnetpp::cValue _CONNECT_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_CONNECT_msg' as cValue -- field index out of range?", field);
    }
}

void _CONNECT_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_CONNECT_msg'", field);
    }
}

const char *_CONNECT_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

omnetpp::any_ptr _CONNECT_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _CONNECT_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _CONNECT_msg *pp = omnetpp::fromAnyPtr<_CONNECT_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_CONNECT_msg'", field);
    }
}

Register_Class(_Info_msg)

_Info_msg::_Info_msg() : ::inet::base_msg()
{
    this->setPacket_type(_Info);

}

_Info_msg::_Info_msg(const _Info_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_Info_msg::~_Info_msg()
{
}

_Info_msg& _Info_msg::operator=(const _Info_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _Info_msg::copy(const _Info_msg& other)
{
    this->topic = other.topic;
    this->Energy = other.Energy;
    this->X = other.X;
    this->Y = other.Y;
}

void _Info_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
    doParsimPacking(b,this->topic);
    doParsimPacking(b,this->Energy);
    doParsimPacking(b,this->X);
    doParsimPacking(b,this->Y);
}

void _Info_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->topic);
    doParsimUnpacking(b,this->Energy);
    doParsimUnpacking(b,this->X);
    doParsimUnpacking(b,this->Y);
}

int _Info_msg::getTopic() const
{
    return this->topic;
}

void _Info_msg::setTopic(int topic)
{
    handleChange();
    this->topic = topic;
}

double _Info_msg::getEnergy() const
{
    return this->Energy;
}

void _Info_msg::setEnergy(double Energy)
{
    handleChange();
    this->Energy = Energy;
}

double _Info_msg::getX() const
{
    return this->X;
}

void _Info_msg::setX(double X)
{
    handleChange();
    this->X = X;
}

double _Info_msg::getY() const
{
    return this->Y;
}

void _Info_msg::setY(double Y)
{
    handleChange();
    this->Y = Y;
}

class _Info_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_topic,
        FIELD_Energy,
        FIELD_X,
        FIELD_Y,
    };
  public:
    _Info_msgDescriptor();
    virtual ~_Info_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_Info_msgDescriptor)

_Info_msgDescriptor::_Info_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_Info_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_Info_msgDescriptor::~_Info_msgDescriptor()
{
    delete[] propertyNames;
}

bool _Info_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_Info_msg *>(obj)!=nullptr;
}

const char **_Info_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_Info_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _Info_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 4+base->getFieldCount() : 4;
}

unsigned int _Info_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_topic
        FD_ISEDITABLE,    // FIELD_Energy
        FD_ISEDITABLE,    // FIELD_X
        FD_ISEDITABLE,    // FIELD_Y
    };
    return (field >= 0 && field < 4) ? fieldTypeFlags[field] : 0;
}

const char *_Info_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "topic",
        "Energy",
        "X",
        "Y",
    };
    return (field >= 0 && field < 4) ? fieldNames[field] : nullptr;
}

int _Info_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "topic") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "Energy") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "X") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "Y") == 0) return baseIndex + 3;
    return base ? base->findField(fieldName) : -1;
}

const char *_Info_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_topic
        "double",    // FIELD_Energy
        "double",    // FIELD_X
        "double",    // FIELD_Y
    };
    return (field >= 0 && field < 4) ? fieldTypeStrings[field] : nullptr;
}

const char **_Info_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_Info_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _Info_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _Info_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_Info_msg'", field);
    }
}

const char *_Info_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _Info_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: return long2string(pp->getTopic());
        case FIELD_Energy: return double2string(pp->getEnergy());
        case FIELD_X: return double2string(pp->getX());
        case FIELD_Y: return double2string(pp->getY());
        default: return "";
    }
}

void _Info_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: pp->setTopic(string2long(value)); break;
        case FIELD_Energy: pp->setEnergy(string2double(value)); break;
        case FIELD_X: pp->setX(string2double(value)); break;
        case FIELD_Y: pp->setY(string2double(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Info_msg'", field);
    }
}

omnetpp::cValue _Info_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: return pp->getTopic();
        case FIELD_Energy: return pp->getEnergy();
        case FIELD_X: return pp->getX();
        case FIELD_Y: return pp->getY();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_Info_msg' as cValue -- field index out of range?", field);
    }
}

void _Info_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: pp->setTopic(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_Energy: pp->setEnergy(value.doubleValue()); break;
        case FIELD_X: pp->setX(value.doubleValue()); break;
        case FIELD_Y: pp->setY(value.doubleValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Info_msg'", field);
    }
}

const char *_Info_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr _Info_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _Info_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _Info_msg *pp = omnetpp::fromAnyPtr<_Info_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Info_msg'", field);
    }
}

Register_Class(_Order_msg)

_Order_msg::_Order_msg() : ::inet::base_msg()
{
    this->setPacket_type(_Order);

}

_Order_msg::_Order_msg(const _Order_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_Order_msg::~_Order_msg()
{
}

_Order_msg& _Order_msg::operator=(const _Order_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _Order_msg::copy(const _Order_msg& other)
{
    this->Device = other.Device;
    this->Operation = other.Operation;
    this->value = other.value;
}

void _Order_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
    doParsimPacking(b,this->Device);
    doParsimPacking(b,this->Operation);
    doParsimPacking(b,this->value);
}

void _Order_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->Device);
    doParsimUnpacking(b,this->Operation);
    doParsimUnpacking(b,this->value);
}

const char * _Order_msg::getDevice() const
{
    return this->Device.c_str();
}

void _Order_msg::setDevice(const char * Device)
{
    handleChange();
    this->Device = Device;
}

int _Order_msg::getOperation() const
{
    return this->Operation;
}

void _Order_msg::setOperation(int Operation)
{
    handleChange();
    this->Operation = Operation;
}

const char * _Order_msg::getValue() const
{
    return this->value.c_str();
}

void _Order_msg::setValue(const char * value)
{
    handleChange();
    this->value = value;
}

class _Order_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_Device,
        FIELD_Operation,
        FIELD_value,
    };
  public:
    _Order_msgDescriptor();
    virtual ~_Order_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_Order_msgDescriptor)

_Order_msgDescriptor::_Order_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_Order_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_Order_msgDescriptor::~_Order_msgDescriptor()
{
    delete[] propertyNames;
}

bool _Order_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_Order_msg *>(obj)!=nullptr;
}

const char **_Order_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_Order_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _Order_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 3+base->getFieldCount() : 3;
}

unsigned int _Order_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_Device
        FD_ISEDITABLE,    // FIELD_Operation
        FD_ISEDITABLE,    // FIELD_value
    };
    return (field >= 0 && field < 3) ? fieldTypeFlags[field] : 0;
}

const char *_Order_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "Device",
        "Operation",
        "value",
    };
    return (field >= 0 && field < 3) ? fieldNames[field] : nullptr;
}

int _Order_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "Device") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "Operation") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "value") == 0) return baseIndex + 2;
    return base ? base->findField(fieldName) : -1;
}

const char *_Order_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "string",    // FIELD_Device
        "int",    // FIELD_Operation
        "string",    // FIELD_value
    };
    return (field >= 0 && field < 3) ? fieldTypeStrings[field] : nullptr;
}

const char **_Order_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_Order_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _Order_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _Order_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_Order_msg'", field);
    }
}

const char *_Order_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _Order_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Device: return oppstring2string(pp->getDevice());
        case FIELD_Operation: return long2string(pp->getOperation());
        case FIELD_value: return oppstring2string(pp->getValue());
        default: return "";
    }
}

void _Order_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Device: pp->setDevice((value)); break;
        case FIELD_Operation: pp->setOperation(string2long(value)); break;
        case FIELD_value: pp->setValue((value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Order_msg'", field);
    }
}

omnetpp::cValue _Order_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Device: return pp->getDevice();
        case FIELD_Operation: return pp->getOperation();
        case FIELD_value: return pp->getValue();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_Order_msg' as cValue -- field index out of range?", field);
    }
}

void _Order_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        case FIELD_Device: pp->setDevice(value.stringValue()); break;
        case FIELD_Operation: pp->setOperation(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_value: pp->setValue(value.stringValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Order_msg'", field);
    }
}

const char *_Order_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr _Order_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _Order_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _Order_msg *pp = omnetpp::fromAnyPtr<_Order_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Order_msg'", field);
    }
}

Register_Class(_Join_msg)

_Join_msg::_Join_msg() : ::inet::base_msg()
{
    this->setPacket_type(_Join);
}

_Join_msg::_Join_msg(const _Join_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_Join_msg::~_Join_msg()
{
}

_Join_msg& _Join_msg::operator=(const _Join_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _Join_msg::copy(const _Join_msg& other)
{
}

void _Join_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
}

void _Join_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
}

class _Join_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
    };
  public:
    _Join_msgDescriptor();
    virtual ~_Join_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_Join_msgDescriptor)

_Join_msgDescriptor::_Join_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_Join_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_Join_msgDescriptor::~_Join_msgDescriptor()
{
    delete[] propertyNames;
}

bool _Join_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_Join_msg *>(obj)!=nullptr;
}

const char **_Join_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_Join_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _Join_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 0+base->getFieldCount() : 0;
}

unsigned int _Join_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    return 0;
}

const char *_Join_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

int _Join_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->findField(fieldName) : -1;
}

const char *_Join_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

const char **_Join_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_Join_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _Join_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _Join_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_Join_msg'", field);
    }
}

const char *_Join_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _Join_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: return "";
    }
}

void _Join_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Join_msg'", field);
    }
}

omnetpp::cValue _Join_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_Join_msg' as cValue -- field index out of range?", field);
    }
}

void _Join_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Join_msg'", field);
    }
}

const char *_Join_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    return nullptr;
}

omnetpp::any_ptr _Join_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _Join_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _Join_msg *pp = omnetpp::fromAnyPtr<_Join_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_Join_msg'", field);
    }
}

Register_Class(_PUBLISH_msg)

_PUBLISH_msg::_PUBLISH_msg() : ::inet::base_msg()
{
    this->setPacket_type(_PUBLISH);

}

_PUBLISH_msg::_PUBLISH_msg(const _PUBLISH_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_PUBLISH_msg::~_PUBLISH_msg()
{
}

_PUBLISH_msg& _PUBLISH_msg::operator=(const _PUBLISH_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _PUBLISH_msg::copy(const _PUBLISH_msg& other)
{
    this->topic = other.topic;
    this->PUBLISH_ID = other.PUBLISH_ID;
    this->double_value = other.double_value;
    this->int_value = other.int_value;
    this->bool_value = other.bool_value;
    this->unit = other.unit;
    this->data = other.data;
    this->PKey = other.PKey;
}

void _PUBLISH_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
    doParsimPacking(b,this->topic);
    doParsimPacking(b,this->PUBLISH_ID);
    doParsimPacking(b,this->double_value);
    doParsimPacking(b,this->int_value);
    doParsimPacking(b,this->bool_value);
    doParsimPacking(b,this->unit);
    doParsimPacking(b,this->data);
    doParsimPacking(b,this->PKey);
}

void _PUBLISH_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->topic);
    doParsimUnpacking(b,this->PUBLISH_ID);
    doParsimUnpacking(b,this->double_value);
    doParsimUnpacking(b,this->int_value);
    doParsimUnpacking(b,this->bool_value);
    doParsimUnpacking(b,this->unit);
    doParsimUnpacking(b,this->data);
    doParsimUnpacking(b,this->PKey);
}

int _PUBLISH_msg::getTopic() const
{
    return this->topic;
}

void _PUBLISH_msg::setTopic(int topic)
{
    handleChange();
    this->topic = topic;
}

int _PUBLISH_msg::getPUBLISH_ID() const
{
    return this->PUBLISH_ID;
}

void _PUBLISH_msg::setPUBLISH_ID(int PUBLISH_ID)
{
    handleChange();
    this->PUBLISH_ID = PUBLISH_ID;
}

double _PUBLISH_msg::getDouble_value() const
{
    return this->double_value;
}

void _PUBLISH_msg::setDouble_value(double double_value)
{
    handleChange();
    this->double_value = double_value;
}

int _PUBLISH_msg::getInt_value() const
{
    return this->int_value;
}

void _PUBLISH_msg::setInt_value(int int_value)
{
    handleChange();
    this->int_value = int_value;
}

bool _PUBLISH_msg::getBool_value() const
{
    return this->bool_value;
}

void _PUBLISH_msg::setBool_value(bool bool_value)
{
    handleChange();
    this->bool_value = bool_value;
}

const char * _PUBLISH_msg::getUnit() const
{
    return this->unit.c_str();
}

void _PUBLISH_msg::setUnit(const char * unit)
{
    handleChange();
    this->unit = unit;
}

uint64_t _PUBLISH_msg::getData() const
{
    return this->data;
}

void _PUBLISH_msg::setData(uint64_t data)
{
    handleChange();
    this->data = data;
}

const char * _PUBLISH_msg::getPKey() const
{
    return this->PKey.c_str();
}

void _PUBLISH_msg::setPKey(const char * PKey)
{
    handleChange();
    this->PKey = PKey;
}

class _PUBLISH_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_topic,
        FIELD_PUBLISH_ID,
        FIELD_double_value,
        FIELD_int_value,
        FIELD_bool_value,
        FIELD_unit,
        FIELD_data,
        FIELD_PKey,
    };
  public:
    _PUBLISH_msgDescriptor();
    virtual ~_PUBLISH_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_PUBLISH_msgDescriptor)

_PUBLISH_msgDescriptor::_PUBLISH_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_PUBLISH_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_PUBLISH_msgDescriptor::~_PUBLISH_msgDescriptor()
{
    delete[] propertyNames;
}

bool _PUBLISH_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_PUBLISH_msg *>(obj)!=nullptr;
}

const char **_PUBLISH_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_PUBLISH_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _PUBLISH_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 8+base->getFieldCount() : 8;
}

unsigned int _PUBLISH_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_topic
        FD_ISEDITABLE,    // FIELD_PUBLISH_ID
        FD_ISEDITABLE,    // FIELD_double_value
        FD_ISEDITABLE,    // FIELD_int_value
        FD_ISEDITABLE,    // FIELD_bool_value
        FD_ISEDITABLE,    // FIELD_unit
        FD_ISEDITABLE,    // FIELD_data
        FD_ISEDITABLE,    // FIELD_PKey
    };
    return (field >= 0 && field < 8) ? fieldTypeFlags[field] : 0;
}

const char *_PUBLISH_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "topic",
        "PUBLISH_ID",
        "double_value",
        "int_value",
        "bool_value",
        "unit",
        "data",
        "PKey",
    };
    return (field >= 0 && field < 8) ? fieldNames[field] : nullptr;
}

int _PUBLISH_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "topic") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "PUBLISH_ID") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "double_value") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "int_value") == 0) return baseIndex + 3;
    if (strcmp(fieldName, "bool_value") == 0) return baseIndex + 4;
    if (strcmp(fieldName, "unit") == 0) return baseIndex + 5;
    if (strcmp(fieldName, "data") == 0) return baseIndex + 6;
    if (strcmp(fieldName, "PKey") == 0) return baseIndex + 7;
    return base ? base->findField(fieldName) : -1;
}

const char *_PUBLISH_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_topic
        "int",    // FIELD_PUBLISH_ID
        "double",    // FIELD_double_value
        "int",    // FIELD_int_value
        "bool",    // FIELD_bool_value
        "string",    // FIELD_unit
        "uint64",    // FIELD_data
        "string",    // FIELD_PKey
    };
    return (field >= 0 && field < 8) ? fieldTypeStrings[field] : nullptr;
}

const char **_PUBLISH_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_PUBLISH_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _PUBLISH_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _PUBLISH_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_PUBLISH_msg'", field);
    }
}

const char *_PUBLISH_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _PUBLISH_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: return long2string(pp->getTopic());
        case FIELD_PUBLISH_ID: return long2string(pp->getPUBLISH_ID());
        case FIELD_double_value: return double2string(pp->getDouble_value());
        case FIELD_int_value: return long2string(pp->getInt_value());
        case FIELD_bool_value: return bool2string(pp->getBool_value());
        case FIELD_unit: return oppstring2string(pp->getUnit());
        case FIELD_data: return uint642string(pp->getData());
        case FIELD_PKey: return oppstring2string(pp->getPKey());
        default: return "";
    }
}

void _PUBLISH_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: pp->setTopic(string2long(value)); break;
        case FIELD_PUBLISH_ID: pp->setPUBLISH_ID(string2long(value)); break;
        case FIELD_double_value: pp->setDouble_value(string2double(value)); break;
        case FIELD_int_value: pp->setInt_value(string2long(value)); break;
        case FIELD_bool_value: pp->setBool_value(string2bool(value)); break;
        case FIELD_unit: pp->setUnit((value)); break;
        case FIELD_data: pp->setData(string2uint64(value)); break;
        case FIELD_PKey: pp->setPKey((value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_PUBLISH_msg'", field);
    }
}

omnetpp::cValue _PUBLISH_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: return pp->getTopic();
        case FIELD_PUBLISH_ID: return pp->getPUBLISH_ID();
        case FIELD_double_value: return pp->getDouble_value();
        case FIELD_int_value: return pp->getInt_value();
        case FIELD_bool_value: return pp->getBool_value();
        case FIELD_unit: return pp->getUnit();
        case FIELD_data: return omnetpp::checked_int_cast<omnetpp::intval_t>(pp->getData());
        case FIELD_PKey: return pp->getPKey();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_PUBLISH_msg' as cValue -- field index out of range?", field);
    }
}

void _PUBLISH_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        case FIELD_topic: pp->setTopic(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_PUBLISH_ID: pp->setPUBLISH_ID(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_double_value: pp->setDouble_value(value.doubleValue()); break;
        case FIELD_int_value: pp->setInt_value(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_bool_value: pp->setBool_value(value.boolValue()); break;
        case FIELD_unit: pp->setUnit(value.stringValue()); break;
        case FIELD_data: pp->setData(omnetpp::checked_int_cast<uint64_t>(value.intValue())); break;
        case FIELD_PKey: pp->setPKey(value.stringValue()); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_PUBLISH_msg'", field);
    }
}

const char *_PUBLISH_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr _PUBLISH_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _PUBLISH_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _PUBLISH_msg *pp = omnetpp::fromAnyPtr<_PUBLISH_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_PUBLISH_msg'", field);
    }
}

Register_Class(_ACK_msg)

_ACK_msg::_ACK_msg() : ::inet::base_msg()
{
    this->setPacket_type(_ACK);

}

_ACK_msg::_ACK_msg(const _ACK_msg& other) : ::inet::base_msg(other)
{
    copy(other);
}

_ACK_msg::~_ACK_msg()
{
}

_ACK_msg& _ACK_msg::operator=(const _ACK_msg& other)
{
    if (this == &other) return *this;
    ::inet::base_msg::operator=(other);
    copy(other);
    return *this;
}

void _ACK_msg::copy(const _ACK_msg& other)
{
    this->ACK_type = other.ACK_type;
    this->Ack_Flags = other.Ack_Flags;
}

void _ACK_msg::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::inet::base_msg::parsimPack(b);
    doParsimPacking(b,this->ACK_type);
    doParsimPacking(b,this->Ack_Flags);
}

void _ACK_msg::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::inet::base_msg::parsimUnpack(b);
    doParsimUnpacking(b,this->ACK_type);
    doParsimUnpacking(b,this->Ack_Flags);
}

int _ACK_msg::getACK_type() const
{
    return this->ACK_type;
}

void _ACK_msg::setACK_type(int ACK_type)
{
    handleChange();
    this->ACK_type = ACK_type;
}

int _ACK_msg::getAck_Flags() const
{
    return this->Ack_Flags;
}

void _ACK_msg::setAck_Flags(int Ack_Flags)
{
    handleChange();
    this->Ack_Flags = Ack_Flags;
}

class _ACK_msgDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_ACK_type,
        FIELD_Ack_Flags,
    };
  public:
    _ACK_msgDescriptor();
    virtual ~_ACK_msgDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(_ACK_msgDescriptor)

_ACK_msgDescriptor::_ACK_msgDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(inet::_ACK_msg)), "inet::base_msg")
{
    propertyNames = nullptr;
}

_ACK_msgDescriptor::~_ACK_msgDescriptor()
{
    delete[] propertyNames;
}

bool _ACK_msgDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<_ACK_msg *>(obj)!=nullptr;
}

const char **_ACK_msgDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *_ACK_msgDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int _ACK_msgDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 2+base->getFieldCount() : 2;
}

unsigned int _ACK_msgDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_ACK_type
        FD_ISEDITABLE,    // FIELD_Ack_Flags
    };
    return (field >= 0 && field < 2) ? fieldTypeFlags[field] : 0;
}

const char *_ACK_msgDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "ACK_type",
        "Ack_Flags",
    };
    return (field >= 0 && field < 2) ? fieldNames[field] : nullptr;
}

int _ACK_msgDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "ACK_type") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "Ack_Flags") == 0) return baseIndex + 1;
    return base ? base->findField(fieldName) : -1;
}

const char *_ACK_msgDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_ACK_type
        "int",    // FIELD_Ack_Flags
    };
    return (field >= 0 && field < 2) ? fieldTypeStrings[field] : nullptr;
}

const char **_ACK_msgDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *_ACK_msgDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int _ACK_msgDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        default: return 0;
    }
}

void _ACK_msgDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class '_ACK_msg'", field);
    }
}

const char *_ACK_msgDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string _ACK_msgDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        case FIELD_ACK_type: return long2string(pp->getACK_type());
        case FIELD_Ack_Flags: return long2string(pp->getAck_Flags());
        default: return "";
    }
}

void _ACK_msgDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        case FIELD_ACK_type: pp->setACK_type(string2long(value)); break;
        case FIELD_Ack_Flags: pp->setAck_Flags(string2long(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_ACK_msg'", field);
    }
}

omnetpp::cValue _ACK_msgDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        case FIELD_ACK_type: return pp->getACK_type();
        case FIELD_Ack_Flags: return pp->getAck_Flags();
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class '_ACK_msg' as cValue -- field index out of range?", field);
    }
}

void _ACK_msgDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        case FIELD_ACK_type: pp->setACK_type(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_Ack_Flags: pp->setAck_Flags(omnetpp::checked_int_cast<int>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_ACK_msg'", field);
    }
}

const char *_ACK_msgDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr _ACK_msgDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void _ACK_msgDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    _ACK_msg *pp = omnetpp::fromAnyPtr<_ACK_msg>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class '_ACK_msg'", field);
    }
}

}  // namespace inet

namespace omnetpp {

}  // namespace omnetpp

