#ifndef __controllerApp_H
#define __controllerApp_H
#include <fstream>

#include "inet/applications/base/ApplicationBase.h"
#include "inet/applications/base/ApplicationPacket_m.h"
#include "inet/transportlayer/contract/udp/UdpSocket.h"
#include "inet/transportlayer/contract/udp/UdpControlInfo_m.h"

#include "inet/common/ModuleAccess.h"
#include "inet/common/packet/Packet.h"
#include "inet/common/TagBase_m.h"
#include "inet/common/TimeTag_m.h"
#include "inet/common/lifecycle/ModuleOperations.h"
#include "inet/common/clock/ClockUserModuleMixin.h"

#include "inet/networklayer/common/L3AddressResolver.h"
#include "inet/networklayer/common/FragmentationTag_m.h"
#include "inet/Encryption/base58/define.h"
#include "inet/Encryption/RSA/rsa.h"
#include "inet/Encryption/base58/base58.h"
#include "inet/Encryption/tea/xtea.h"
#include "inet/Encryption/AES/aes.h"
#include "inet/Encryption/SHA512/sha512.h"
#include "../MyPacket_m.h"

namespace inet {
struct Node{
    std::string name;
    int topic;
    double Energy;
    double X;
    double Y;
    std::string header;
    int group;
};
class INET_API controllerApp : public ApplicationBase, public UdpSocket::ICallback{
  protected:
    enum SelfMsgKinds { START = 1, SEND };


    std::string Scenario;
    UdpSocket socket;
    int localPort = -1;
    L3Address multicastGroup;
    cMessage *selfMsg = nullptr;
    int Device_Type;
    // statistics
    int numSent = 0;
    int numReceived = 0;
    std::vector<Node> Nodes;
    std::vector<Node> heads;
    int Node_info=0;
    int numSensor;
    std::vector<std::string> debug;
  public:
    controllerApp() {}
    virtual ~controllerApp(){
        cancelAndDelete(selfMsg);
    };

  protected:
    virtual void setSocketOptions(){
        bool receiveBroadcast = par("receiveBroadcast");
        if (receiveBroadcast)
            socket.setBroadcast(true);

        MulticastGroupList mgl = getModuleFromPar<IInterfaceTable>(par("interfaceTableModule"), this)->collectMulticastGroups();
        socket.joinLocalMulticastGroups(mgl);

        // join multicastGroup
        const char *groupAddr = par("multicastGroup");
        multicastGroup = L3AddressResolver().resolve(groupAddr);
        if (!multicastGroup.isUnspecified()) {
            if (!multicastGroup.isMulticast())
                throw cRuntimeError("Wrong multicastGroup setting: not a multicast address: %s", groupAddr);
            socket.joinMulticastGroup(multicastGroup);
        }
        socket.setCallback(this);
    };

  protected:
    virtual int numInitStages() const override { return NUM_INIT_STAGES; }
    virtual void initialize(int stage) override{
        ApplicationBase::initialize(stage);
        if (stage == INITSTAGE_LOCAL) {
            Scenario = getParentModule()->getParentModule()->par("Scenario").stringValue();
            numSensor = getParentModule()->getParentModule()->par("numSensor");
            numReceived = 0;
            numSent = 0;
            Node_info=0;
            WATCH(numSent);
            WATCH(numReceived);
            localPort = par("localPort");
            selfMsg = new cMessage("controllerAppTimer");
        }
    };
    void handle_START(cMessage *msg);
    double distance(double x1, double y1, double x2, double y2){
        return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
    }
    int GetGroup(int i){
        double myDist;
        int N;
        N=0;
        for(int i2=0;i2<Nodes.size()-1;i2++)
            if(Nodes[i].header =="")
                if(distance(Nodes[i].X , Nodes[i].Y, Nodes[i2].X, Nodes[i2].Y)<50)
                    N++;
        return N;
    }
    void SetHeader(int Limit){
        int G=0;
        int H =-1;
        std::ostringstream str;
        for(int i=0;i<Nodes.size()-1;i++)
            if(Nodes[i].header =="")
                if(GetGroup(i)>G){
                   G=GetGroup(i);
                   H =i;
                }
        EV << "=========SendClustering=========== " << H <<"\n";
        if(H !=-1){
            int l=0;
            for(int i=0;i<Nodes.size()-1;i++)
                if(Nodes[i].header =="")
                    if(distance(Nodes[i].X , Nodes[i].Y, Nodes[H].X, Nodes[H].Y)<50){
                        Node N;
                        N.name   = Nodes[i].name;
                        N.topic  = Nodes[i].topic;
                        N.Energy = Nodes[i].Energy;
                        N.X      = Nodes[i].X;
                        N.Y      = Nodes[i].Y;
                        N.header = Nodes[H].name;
                        if(l <= Limit || l == -1){
                            Nodes.at(i) = N;
                            Send_Order(Create_Order(Nodes[H].name,H,"Clustering"),Nodes[i].name ,5000);
                        }
                    }
            heads.push_back(Nodes[H]);
        }
    }
    void EnergyClustering(){
        for(int i=0;i<Nodes.size()-1;i++){
            Send_Order(Create_Order("",3,"Clustering"),Nodes[i].name ,5000);
        }
    }
    void LimitClustering(){
        for(int i=0;i<Nodes.size()-1;i++)
           SetHeader(4);
        for(int i=0;i<Nodes.size()-1;i++){
            Send_Order(Create_Order("",2,"Clustering"),Nodes[i].name ,5000);
        }
    }
    void DistanceClustering(){
        for(int i=0;i<Nodes.size()-1;i++)
           SetHeader(-1);

        for(int i=0;i<Nodes.size()-1;i++){
            Send_Order(Create_Order("",1,"Clustering"),Nodes[i].name ,5000);
        }


    };
    virtual void handleMessageWhenUp(cMessage *msg) override{
        if (msg->isSelfMessage()) {
            ASSERT(msg == selfMsg);
            switch (selfMsg->getKind()) {
                case START:
                    handle_START(msg);
                    break;
                case SEND:

                    break;
            }
        }else if (msg->arrivedOn("socketIn"))
            socket.processMessage(msg);
        else
            throw cRuntimeError("Unknown incoming gate: '%s'", msg->getArrivalGate()->getFullName());
    };
    virtual void print_NodeTable(std::vector<Node> N) {
        std::ostringstream str;
        str << " name  |" << " topic    |" << " Energy    |  " << "X    |  " << "Y    |  " << "header " << "group " <<"\n";
        for(int i=0;i<N.size()-1;i++){
            str <<
                N[i].name.c_str()<< "    |  " <<
                N[i].topic << "   |  " <<
                N[i].Energy << "   |  " <<
                N[i].X << "   |  " <<
                N[i].Y << "   |  " <<
                N[i].header << "   |  " <<
                GetGroup(i) << "   |  " <<"\n";
        }
         add_debug(str.str().c_str());
    }
    virtual void finish() override{
        ApplicationBase::finish();

        debug_file();
        recordScalar("packets sent", numSent);
        recordScalar("packets received", numReceived);
    };

    virtual void refreshDisplay() const override{
        ApplicationBase::refreshDisplay();

        char buf[100];
        sprintf(buf, "rcvd: %d pks\nsent: %d pks", numReceived, numSent);
        getDisplayString().setTagArg("t", 0, buf);
    };

    virtual void socketDataArrived(UdpSocket *socket, Packet *packet) override{
        const auto& msg = packet->peekAtFront<base_msg>();
        switch (msg->getPacket_type()) {
        EV << "===========================" << msg->getPacket_type()<< "====================================\n";
            case _CONNECT :
                handle_CONNECT(packet);
            break;
            case _Info :
                handle_Info(packet);
            break;
            case _PUBLISH :
                handle_PUBLISH(packet);
            break;
            case _ACK :
                handle_ACK(packet);
            break;
        }
        emit(packetReceivedSignal, packet);
        delete packet;
        numReceived++;
    };
    virtual void socketErrorArrived(UdpSocket *socket, Indication *indication) override{
        EV_WARN << "Ignoring UDP error report " << indication->getName() << endl;
        delete indication;
    };
    virtual void socketClosed(UdpSocket *socket) override{
        if (operationalState == State::STOPPING_OPERATION)
            startActiveOperationExtraTimeOrFinish(par("stopOperationExtraTime"));
    };

    virtual void handleStartOperation(LifecycleOperation *operation) override{
        socket.setOutputGate(gate("socketOut"));
        socket.bind(5000);
        setSocketOptions();
        selfMsg->setKind(START);
        scheduleAt(simTime(), selfMsg);
    };
    virtual void handleStopOperation(LifecycleOperation *operation) override{
        cancelEvent(selfMsg);
        if (!multicastGroup.isUnspecified())
            socket.leaveMulticastGroup(multicastGroup);
        socket.close();
        delayActiveOperationFinish(par("stopOperationTimeout"));
    };
    virtual void handleCrashOperation(LifecycleOperation *operation) override{
        cancelEvent(selfMsg);
        if (operation->getRootModule() != getContainingNode(this)) {
            if (!multicastGroup.isUnspecified())
                socket.leaveMulticastGroup(multicastGroup);
            socket.destroy();
        }
    };


    Packet *Create_Order(std::string Device,int Operation,std::string value);
    Packet *Create_ACK(int ACK_type,int Ack_Flag);

    void Send_Order(Packet *packet,std::string to ,int port);
    void Send_ACK(Packet *packet,std::string to ,int port);

    void handle_CONNECT(Packet *packet);
    void handle_Info(Packet *packet);
    void handle_PUBLISH(Packet *packet);
    void handle_encrypt_PUBLISH(Packet *packet);
    void handle_ACK(Packet *packet);

    void debug_file(){
        std::ofstream myfile;
        char buf[100];
        std::ostringstream str;
        str << getParentModule()->getName() ;
        sprintf(buf, "debug/%s.txt",str.str().c_str());
        myfile.open (buf);
        for (auto i = debug.begin(); i != debug.end(); ++i)
            myfile << *i << "\n";
        myfile.close();
    }
    void add_debug(std::string title, double value){
        std::ostringstream str1;
        str1 << title << " : "  << value << " on " << simTime() ;
        debug.push_back(str1.str().c_str()) ;
    }
    void add_debug(std::string title){
        debug.push_back(title) ;
    }
};

}

#endif

