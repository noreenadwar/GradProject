#include "controllerApp.h"

namespace inet {

Define_Module(controllerApp);

void controllerApp::handle_START(cMessage *msg){

}

Packet *controllerApp::Create_Order(std::string Device,int Operation,std::string value){
    Packet *packet = new Packet("Order");
    const auto& payload = makeShared<_Order_msg>();
        payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        payload->setSensor_name(getParentModule()->getName());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
        payload->setDevice(Device.c_str());
        payload->setOperation(Operation);
        payload->setValue(value.c_str());
    packet->insertAtBack(payload);
    return packet;
};
Packet *controllerApp::Create_ACK(int ACK_type,int Ack_Flag){
    Packet *packet = new Packet("ACK");
    const auto& payload = makeShared<_ACK_msg>();
        payload->setChunkLength(B(1000));
        payload->addTag<CreationTimeTag>()->setCreationTime(simTime());
        payload->setSensor_name(getParentModule()->getName());
        payload->setPacket_ID(numSent);
        payload->setDevice_Type(Device_Type);
        payload->setCreation_Time(simTime().dbl());
        payload->setACK_type(ACK_type);
        payload->setAck_Flags(Ack_Flag);
    packet->insertAtBack(payload);
  return packet;
};

void controllerApp::Send_Order(Packet *packet,std::string to ,int port){
    char buf[100];
    sprintf(buf, "Send_Order to: %s", to.c_str());
    add_debug(buf);

    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    if (!destAddr.isUnspecified()){
        emit(packetSentSignal, packet);
        socket.sendTo(packet, destAddr, port);
        numSent++;
    }
};
void controllerApp::Send_ACK(Packet *packet,std::string to ,int port){
    char buf[100];
    sprintf(buf, "Send_ACK to: %s", to.c_str());
    add_debug(buf);
    L3Address destAddr ;
    L3AddressResolver().tryResolve(to.c_str(), destAddr);
    if (!destAddr.isUnspecified()){
        emit(packetSentSignal, packet);
        socket.sendTo(packet, destAddr, port);
        numSent++;
    }
};

void controllerApp::handle_CONNECT(Packet *packet){
    const auto& msg = packet->peekAtFront<_CONNECT_msg>();
    char buf[100];
    sprintf(buf, "handle_CONNECT from: %s", msg->getSensor_name());
    add_debug(buf);
    std::string node = msg->getSensor_name();
    Send_ACK(Create_ACK(_CONNECT,_received),node ,5000);
}
void controllerApp::handle_Info(Packet *packet){
     const auto& msg = packet->peekAtFront<_Info_msg>();
    char buf[100];
    sprintf(buf, "handle_Info from: %s", msg->getSensor_name());
    add_debug(buf);
    Node N;
        N.name =msg->getSensor_name() ;
        N.topic= msg->getTopic() ;
        N.Energy = msg->getEnergy();
        N.X= msg->getX();
        N.Y= msg->getY();
        N.header ="";
        N.group =-1;
    Nodes.push_back(N);
    Node_info++;
        Send_Order(Create_Order("",-1,"Clustering"),msg->getSensor_name() ,5000);

}
void controllerApp::handle_PUBLISH(Packet *packet){
   const auto& msg = packet->peekAtFront<_PUBLISH_msg>();
   char buf[100];
   sprintf(buf, "handle_PUBLISH from: %s", msg->getSensor_name());
   add_debug(buf);

   EV << "name:" << msg->getSensor_name()            << "\n";
   EV << "int_value:" << msg->getInt_value() << "\n";

}
void handle_encrypt_PUBLISH(Packet *packet){
    const auto& msg = packet->peekAtFront<_PUBLISH_msg>();
       EV << "name:" << msg->getSensor_name()            << "\n";
       EV << "int_value:" << msg->getInt_value() << "\n";

        uint64 Enlen = msg->getData();
        ubyte* buf = new ubyte[20 * 2 + 256];  //256 is key size.
        ubyte* buf2 = new ubyte[20 * 2];

        string ret1((char*)buf, Enlen);
        uint64 Delen =  crypto::rsa::RSA::decrypt(msg->getPKey(), buf, Enlen, buf2);
        string ret((char*)buf2, Delen);


}
void controllerApp::handle_ACK(Packet *packet){
   const auto& msg = packet->peekAtFront<_ACK_msg>();
   char buf[100];
     sprintf(buf, "handle_ACK from: %s", msg->getSensor_name());
     add_debug(buf);
   EV << "handle_ACK=============Node: controller==================="  << "\n";
   EV << "name:" << msg->getSensor_name()            << "\n";
}

}

