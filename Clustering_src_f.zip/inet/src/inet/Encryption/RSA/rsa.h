#pragma once

#include "../utils/types.h"
#include "../utils/bigint.h"
#include "../utils/random.h"

using namespace std;
using namespace crypto::utils;

namespace crypto
{
namespace rsa
{

struct RSAKeyPair
{
public:
    string privateKey;
    string publicKey;

    RSAKeyPair()
    {
    }

    RSAKeyPair(string privateKey, string publicKey)
    {
        this->privateKey    = privateKey;
        this->publicKey     = publicKey;
    }
};

struct RSAKeyInfo
{
public:
    BigInt  modulus;
    BigInt  exponent;

    RSAKeyInfo()
    {
    }

    RSAKeyInfo(BigInt modulus, BigInt exponent)
    {
        this->modulus       = modulus;
        this->exponent      = exponent;
    }
};

class RSA
{
public:
    static RSAKeyPair generateKeyPair(uint);
    static string encodeKey(BigInt, BigInt);
    static RSAKeyInfo decodeKey(string const&);
    static uint64 encrypt(string const&, string const&, ubyte*);
    static uint64 decrypt(string const&, ubyte*, uint64, ubyte*, bool mixinXteaMode = false);
    static uint64 decrypt(RSAKeyInfo, ubyte*, uint64, ubyte*, bool mixinXteaMode = false);

private:
    static uint64 encrypt_mixinXteaMode(RSAKeyInfo, ubyte*, uint64, ubyte*);
    static uint64 decrypt_mixinXteaMode(RSAKeyInfo, ubyte*, uint64, ubyte*);

    static void generateXteaKey(ubyte* buf, uint64 len, int* xteaKey);
};

}
}
