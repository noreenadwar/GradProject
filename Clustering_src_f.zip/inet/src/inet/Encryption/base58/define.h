#ifndef INET_ENCRYPTION_BASE58_DEFINE_H_
#define INET_ENCRYPTION_BASE58_DEFINE_H_

namespace inet {
struct iNode{
    std::string icon;
    std::string color;
    double X;
    double Y;
    double header;
};
class define {

public:
    std::vector<iNode> _Nodes;
    void sett(int N){
            EV << "====================define=================\n";

        }
    int set(int N){
            std::ifstream filestream;
            std::string line;

            if (N==1)
                filestream.open("/home/simu5g/simu5g-workspace/inet/src/inet/Encryption/base58/distance.txt", std::ifstream::in);
            if (N==2)
                filestream.open("/home/simu5g/simu5g-workspace/inet/src/inet/Encryption/base58/energy.txt", std::ifstream::in);
            if (N==3)
                filestream.open("/home/simu5g/simu5g-workspace/inet/src/inet/Encryption/base58/limit.txt", std::ifstream::in);

                while ( getline(filestream, line) ){
                        const char *destAddrs = line.c_str();
                        cStringTokenizer tokenizer(destAddrs);
                          const char *token;
                          int N=0;
                          iNode Ni;
                          while ((token = tokenizer.nextToken()) != nullptr) {
                              if(N==0)
                                  Ni.X = std::stod(token);
                              if(N==1)
                                  Ni.Y = std::stod(token);
                              if(N==2)
                                  Ni.icon = token;
                              if(N==3)
                                  Ni.color = token;
                              if(N==4)
                                  Ni.header = std::stod(token);
                             N++;
                          }
                          _Nodes.push_back(Ni);
                    }


            return 0;
        }
};

} /* namespace inet */

#endif /* INET_ENCRYPTION_BASE58_DEFINE_H_ */
