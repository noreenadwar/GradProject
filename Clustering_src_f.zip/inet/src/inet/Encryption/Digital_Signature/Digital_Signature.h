#pragma once

#include <cassert>
#include <string>

#include "../utils/types.h"
#include "../utils/utility.h"

using namespace std;
using namespace crypto::utils;

namespace crypto{
namespace Digital_Signature{

class Digital_Signature{
    private:

    public:

};

}}
