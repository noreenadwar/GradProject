#!/bin/sh
java -jar ./tool/ArduSpreadsheet.jar

